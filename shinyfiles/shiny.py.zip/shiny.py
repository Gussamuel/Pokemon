import time
import os
from pynput.keyboard import Key, Controller
import pyautogui
import PIL.ImageGrab
import imessage

keyboard = Controller()

def sendText():
    time.sleep(2)
    imessage.send(['+1 6155172055'], 'Shiny found!')
    time.sleep(2)
    imessage.send(['+1 6158303227'], 'Sam found a shiny and has no clue this text has been sent. Surprise him by replying with something funny!')
    time.sleep(2)
    imessage.send(['+1 6159745468'], 'Sam found a shiny and has no clue this text has been sent. Surprise him by replying with something funny!')
    time.sleep(2)
    imessage.send(['+1 6156360599'], 'Sam found a shiny and has no clue this text has been sent. Surprise him by replying with something funny!')

def shinyDetermined():
    rgbShiny = 107, 227, 230, 255
    #rgbShiny2 = 206, 170, 239, 255
    rgb = PIL.ImageGrab.grab().load()[940,420]
    screen = PIL.ImageGrab.grab().size
    print(screen)
    print(rgb)
    if rgb == rgbShiny:
        print("You got yourself a shiny!")
        sendText()
        exit()
    else:
        bigLoop()

def bigLoop():

    count = 0

    while True:

        os.system("open /Applications/Operator.app")
        time.sleep(3)
        pyautogui.keyDown('return')
        pyautogui.keyDown('backspace')
        pyautogui.keyDown('x')
        pyautogui.keyDown('z')
        time.sleep(1)
        pyautogui.keyUp('return')
        pyautogui.keyUp('backspace')
        pyautogui.keyUp('x')
        pyautogui.keyUp('z')
        time.sleep(3)

        for i in range(5):
            keyboard.press('x')
            time.sleep(1)
            keyboard.release('x')
            time.sleep(1)
            count = count+1
            print(count, 'x')
            if count == 5:
                print('PHASE 1 DONE AT 5')

        for i in range(1):
            keyboard.press('z')
            time.sleep(1)
            keyboard.release('z')
            time.sleep(1)
            count = count+1
            print(count, 'z')
            if count == 6:
                print('PHASE 2 DONE AT 6')

        for i in range(6):
            keyboard.press('x')
            time.sleep(1)
            keyboard.release('x')
            time.sleep(1)
            count = count+1
            print(count, 'x')
            if count == 12:
                print('PHASE 3 DONE AT 12')


        for i in range(3):
            keyboard.press('z')
            time.sleep(1.3)
            keyboard.release('z')
            time.sleep(1)
            count = count+1
            print(count, 'z')
            if count == 15:
                print('PHASE 4 DONE AT 15')
        
        for i in range(2):
            keyboard.press('x')
            time.sleep(1)
            keyboard.release('x')
            time.sleep(1)
            count = count+1
            print(count, 'x')
            if count == 17:
                print('PHASE 5 DONE AT 17')
        
        for i in range(1):
            pyautogui.keyDown('return')
            time.sleep(1)
            pyautogui.keyUp('return')
            time.sleep(1)
            count = count+1
            print(count, 'return')
            if count == 18:
                print('PHASE 6 DONE AT 18')

        for i in range(1):
            pyautogui.keyDown('down')
            time.sleep(1)
            pyautogui.keyUp('down')
            time.sleep(1)
            count = count+1
            print(count, 'down')
            if count == 19:
                print('PHASE 7 DONE AT 19')

        for i in range(1):
            keyboard.press('x')
            time.sleep(1)
            keyboard.release('x')
            time.sleep(1)
            count = count+1
            print(count, 'x')
            if count == 20:
                print('PHASE 8 DONE AT 20')
        
        for i in range(2):
            time.sleep(2)
            pyautogui.keyDown('up')
            time.sleep(0.2)
            pyautogui.keyUp('up')
            time.sleep(1)
            count = count+1
            print(count, 'up')
            if count == 22:
                print('PHASE 9 DONE AT 22')

        for i in range(2):
            keyboard.press('x')
            time.sleep(1)
            keyboard.release('x')
            time.sleep(1)
            count = count+1
            print(count, 'x')
            if count == 24:
                print('PHASE 11 DONE AT 24')
                shinyDetermined()

bigLoop()